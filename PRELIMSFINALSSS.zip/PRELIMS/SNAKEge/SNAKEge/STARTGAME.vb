﻿Public Class STARTGAME
    Dim imageLoc1 As String = "C:\Users\Ryzen 5\Desktop\98353670-start-game-come-and-play-game-controller-background-vector-image.jpg"
    Dim imageLoc2 As String = "C:\Users\Ryzen 5\Desktop\game-start-button-png-6.png"
    Private Sub STARTGAME_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        With PictureBox1
            .Image = Image.FromFile(imageLoc1)
            .SizeMode = PictureBoxSizeMode.StretchImage
        End With
        With Button1
            .Image = Image.FromFile(imageLoc2)
        End With
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Form1.Show()
        Me.Hide()
    End Sub
End Class